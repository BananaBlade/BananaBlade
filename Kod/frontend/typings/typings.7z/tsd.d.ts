/// <reference path="_custom/custom.d.ts" />
/// <reference path="whatwg-fetch/whatwg-fetch.d.ts" />

/// <reference path="angular2/angular2.d.ts" />
/// <reference path="angular2/http.d.ts" />
/// <reference path="angular2/router.d.ts" />
/// <reference path="angular2/testing.d.ts" />

///// <reference path="es6-shim/es6-shim.d.ts" />

///// <reference path="jasmine/jasmine.d.ts" />
