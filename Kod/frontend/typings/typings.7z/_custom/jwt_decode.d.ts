interface Window {
  jwt_decode(jwt: string): any;
}
